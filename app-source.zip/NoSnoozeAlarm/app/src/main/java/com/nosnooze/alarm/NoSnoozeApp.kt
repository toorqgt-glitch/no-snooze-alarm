package com.nosnooze.alarm

import android.app.Application
import com.nosnooze.alarm.alarm.Notifications

class NoSnoozeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifications.createChannels(this)
        L.i("App process started")
    }
}
