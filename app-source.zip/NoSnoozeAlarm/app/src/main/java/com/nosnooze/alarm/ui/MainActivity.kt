package com.nosnooze.alarm.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.nosnooze.alarm.R
import com.nosnooze.alarm.alarm.ScheduleResult
import com.nosnooze.alarm.data.Alarm
import com.nosnooze.alarm.data.AlarmRepository
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var repo: AlarmRepository
    private lateinit var adapter: AlarmAdapter
    private lateinit var warningBox: View
    private lateinit var warningText: TextView

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshWarnings() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
        repo = AlarmRepository(this)

        warningBox = findViewById(R.id.warningBox)
        warningText = findViewById(R.id.tvWarning)
        findViewById<MaterialButton>(R.id.btnFixWarning).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val empty = findViewById<TextView>(R.id.emptyView)
        adapter = AlarmAdapter(
            onToggle = { alarm, enabled -> toggle(alarm, enabled) },
            onEdit = { alarm ->
                startActivity(
                    Intent(this, AddEditAlarmActivity::class.java)
                        .putExtra(AddEditAlarmActivity.EXTRA_ALARM_ID, alarm.id)
                )
            },
            onDelete = { alarm -> confirmDelete(alarm) },
        )
        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
        findViewById<MaterialButton>(R.id.btnAddAlarm).setOnClickListener {
            startActivity(Intent(this, AddEditAlarmActivity::class.java))
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.observeAll().collect { list ->
                    adapter.submitList(list)
                    empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshWarnings()
        // Restores AlarmManager entries if Android or a force-stop wiped them.
        lifecycleScope.launch { repo.rescheduleAll("app opened") }
    }

    private fun refreshWarnings() {
        val problems = mutableListOf<String>()
        if (!Permissions.exactAlarmsAllowed(this)) problems += "Exact alarms are not allowed — alarms may ring late."
        if (!Permissions.notificationsAllowed(this)) problems += "Notifications are off — the alarm screen may not appear."
        if (!Permissions.fullScreenAllowed(this)) problems += "Full-screen alarms are not allowed."
        if (Permissions.alarmVolume(this).first == 0) problems += "Alarm volume is 0 — alarms will be silent."
        warningBox.visibility = if (problems.isEmpty()) View.GONE else View.VISIBLE
        warningText.text = problems.joinToString("\n")
    }

    private fun toggle(alarm: Alarm, enabled: Boolean) {
        lifecycleScope.launch {
            val result = repo.setEnabled(alarm, enabled)
            if (result == ScheduleResult.IN_PAST) {
                adapter.notifyDataSetChanged() // snap the switch back
            }
            showResult(result)
        }
    }

    private fun confirmDelete(alarm: Alarm) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete alarm?")
            .setMessage("${AlarmFormat.time(this, alarm)} on ${AlarmFormat.date(alarm)}")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> lifecycleScope.launch { repo.delete(alarm) } }
            .show()
    }

    private fun showResult(result: ScheduleResult) {
        val msg = when (result) {
            ScheduleResult.EXACT -> "Alarm on"
            ScheduleResult.INEXACT -> "Alarm on, but exact alarms are not allowed — it may ring late. See Help."
            ScheduleResult.IN_PAST -> "That time has passed. Edit the alarm to pick a new date/time."
            ScheduleResult.DISABLED -> "Alarm off"
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean =
        if (item.itemId == R.id.action_help) {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        } else super.onOptionsItemSelected(item)
}
