package com.nosnooze.alarm.alarm

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.nosnooze.alarm.L
import com.nosnooze.alarm.R
import com.nosnooze.alarm.ui.AlarmRingingActivity

/** Receives the AlarmManager trigger and immediately hands off to the foreground service. */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_FIRE) return
        val alarmId = intent.getLongExtra(AlarmService.EXTRA_ALARM_ID, -1L)
        L.i("AlarmReceiver fired for alarm $alarmId")
        if (alarmId < 0) return

        try {
            // Exact alarms (setAlarmClock) are exempt from Android 12's background FGS-start restriction.
            AlarmService.start(context, alarmId)
        } catch (e: Exception) {
            // Happens if the alarm was delivered inexactly (exact permission revoked).
            // Fall back to a full-screen notification; the ringing screen starts the service when opened.
            L.e("Could not start alarm service from background; posting fallback notification", e)
            postFallbackNotification(context, alarmId)
        }
    }

    private fun postFallbackNotification(context: Context, alarmId: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            L.e("Notification permission denied: cannot show fallback alarm notification")
            return
        }
        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, AlarmRingingActivity::class.java)
                .putExtra(AlarmService.EXTRA_ALARM_ID, alarmId)
                .putExtra(AlarmRingingActivity.EXTRA_START_SERVICE, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, Notifications.CHANNEL_ALARM)
            .setSmallIcon(R.drawable.ic_alarm)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText("Alarm! Tap to open and stop it.")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(open, true)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(Notifications.NOTIFICATION_ID_RINGING, n)
    }

    companion object {
        const val ACTION_FIRE = "com.nosnooze.alarm.ACTION_FIRE"
    }
}
