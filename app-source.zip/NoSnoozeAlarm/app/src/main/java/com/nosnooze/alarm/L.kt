package com.nosnooze.alarm

import android.util.Log

/** Central logger. Filter Logcat by tag "NoSnoozeAlarm". */
object L {
    private const val TAG = "NoSnoozeAlarm"
    fun d(msg: String) = Log.d(TAG, msg)
    fun i(msg: String) = Log.i(TAG, msg)
    fun w(msg: String, t: Throwable? = null) = Log.w(TAG, msg, t)
    fun e(msg: String, t: Throwable? = null) = Log.e(TAG, msg, t)
}
