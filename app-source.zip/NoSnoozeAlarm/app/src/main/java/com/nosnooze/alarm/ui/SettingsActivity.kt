package com.nosnooze.alarm.ui

import android.os.Build
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.nosnooze.alarm.R

/** Permission status + Samsung battery guidance + honest platform limitations. */
class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        findViewById<MaterialButton>(R.id.btnExact).setOnClickListener { Permissions.openExactAlarmSettings(this) }
        findViewById<MaterialButton>(R.id.btnNotif).setOnClickListener { Permissions.openNotificationSettings(this) }
        findViewById<MaterialButton>(R.id.btnFullScreen).setOnClickListener { Permissions.openFullScreenSettings(this) }
        findViewById<MaterialButton>(R.id.btnBattery).setOnClickListener { Permissions.requestIgnoreBatteryOptimizations(this) }
        findViewById<MaterialButton>(R.id.btnAppInfo).setOnClickListener { Permissions.openAppDetails(this) }
    }

    override fun onResume() {
        super.onResume()
        status(R.id.tvExactStatus, "Exact alarms (Alarms & reminders)", Permissions.exactAlarmsAllowed(this))
        status(R.id.tvNotifStatus, "Notifications (alarm screen + STOP button)", Permissions.notificationsAllowed(this))
        status(
            R.id.tvFullScreenStatus,
            if (Build.VERSION.SDK_INT >= 34) "Full-screen alarm notifications"
            else "Full-screen alarm notifications (auto-allowed on this Android version)",
            Permissions.fullScreenAllowed(this)
        )
        status(R.id.tvBatteryStatus, "Battery optimization disabled for this app", Permissions.ignoringBatteryOptimizations(this))
        val (vol, max) = Permissions.alarmVolume(this)
        status(R.id.tvVolumeStatus, "Alarm volume: $vol / $max", vol > 0)
    }

    private fun status(viewId: Int, label: String, ok: Boolean) {
        val tv = findViewById<TextView>(viewId)
        tv.text = (if (ok) "✅  " else "⚠️  ") + label + if (ok) "" else " — needs attention"
        tv.setTextColor(ContextCompat.getColor(this, if (ok) R.color.status_on else R.color.status_warn))
    }
}
