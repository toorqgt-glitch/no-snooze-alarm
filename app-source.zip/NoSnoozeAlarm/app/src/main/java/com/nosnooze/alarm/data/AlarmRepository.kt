package com.nosnooze.alarm.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.nosnooze.alarm.L
import com.nosnooze.alarm.alarm.AlarmScheduler
import com.nosnooze.alarm.alarm.ScheduleResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class AlarmRepository(context: Context) {
    private val app = context.applicationContext
    private val dao = AppDatabase.get(app).alarmDao()
    private val scheduler = AlarmScheduler(app)

    fun observeAll(): Flow<List<Alarm>> = dao.observeAll()

    suspend fun get(id: Long): Alarm? = withContext(Dispatchers.IO) { dao.getById(id) }

    /** Insert or update, then (re)schedule. Re-scheduling always cancels the old PendingIntent first, so no duplicates. */
    suspend fun save(alarm: Alarm): ScheduleResult = withContext(Dispatchers.IO) {
        val saved = if (alarm.id == 0L) {
            alarm.copy(id = dao.insert(alarm))
        } else {
            dao.update(alarm)
            alarm
        }
        L.i("Saved alarm ${saved.id} time=${saved.hour}:${saved.minute} repeatDays=${saved.repeatDays} enabled=${saved.enabled}")
        val result = scheduler.schedule(saved)
        cleanupUriPermissions()
        result
    }

    suspend fun setEnabled(alarm: Alarm, enabled: Boolean): ScheduleResult = withContext(Dispatchers.IO) {
        if (enabled && alarm.isInPast()) {
            L.w("Refusing to enable alarm ${alarm.id}: time is in the past")
            return@withContext ScheduleResult.IN_PAST
        }
        val updated = alarm.copy(enabled = enabled)
        dao.update(updated)
        scheduler.schedule(updated)
    }

    suspend fun delete(alarm: Alarm) = withContext(Dispatchers.IO) {
        scheduler.cancel(alarm.id)
        dao.delete(alarm)
        L.i("Deleted alarm ${alarm.id}")
        cleanupUriPermissions()
    }

    /**
     * Re-registers every enabled future alarm with AlarmManager. Safe to call any time:
     * after boot, app update, time/time zone change, exact-alarm permission change, or app launch
     * (AlarmManager entries are wiped by a force-stop; opening the app restores them).
     */
    suspend fun rescheduleAll(reason: String) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val all = dao.getAll()
        var scheduled = 0
        for (alarm in all) {
            if (!alarm.enabled) {
                scheduler.cancel(alarm.id)
                continue
            }
            if (alarm.isRepeating()) {
                scheduler.schedule(alarm)
                scheduled++
                continue
            }
            val trigger = alarm.localDateTime().atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
            if (trigger <= now) {
                // Leave very recent alarms alone: they may be ringing right now.
                if (now - trigger > RECENT_GRACE_MS) {
                    L.w("Alarm ${alarm.id} at ${alarm.localDateTime()} was missed (device off / app stopped). Disabling.")
                    dao.setEnabled(alarm.id, false)
                    scheduler.cancel(alarm.id)
                }
                continue
            }
            scheduler.schedule(alarm)
            scheduled++
        }
        L.i("rescheduleAll($reason): $scheduled of ${all.size} alarms scheduled")
    }

    /** Release persisted read grants for audio files no alarm uses anymore. */
    private suspend fun cleanupUriPermissions() {
        try {
            val used = dao.getAll().mapNotNull { it.audioUri }.toSet()
            for (perm in app.contentResolver.persistedUriPermissions) {
                if (perm.uri.toString() !in used) {
                    app.contentResolver.releasePersistableUriPermission(
                        perm.uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                    L.d("Released unused audio permission ${perm.uri}")
                }
            }
        } catch (e: Exception) {
            L.w("URI permission cleanup failed", e)
        }
    }

    companion object {
        private const val RECENT_GRACE_MS = 2 * 60 * 1000L

        fun takeReadPermission(context: Context, uri: Uri): Boolean = try {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            true
        } catch (e: SecurityException) {
            L.w("Could not persist permission for $uri", e)
            false
        }
    }
}
