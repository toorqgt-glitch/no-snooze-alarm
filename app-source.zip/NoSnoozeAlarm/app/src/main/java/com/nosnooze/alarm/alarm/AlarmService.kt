package com.nosnooze.alarm.alarm

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.nosnooze.alarm.L
import com.nosnooze.alarm.R
import com.nosnooze.alarm.data.Alarm
import com.nosnooze.alarm.data.AppDatabase
import com.nosnooze.alarm.ui.AlarmFormat
import com.nosnooze.alarm.ui.AlarmRingingActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Foreground service that owns alarm playback.
 *
 * - Plays the alarm's audio once, start to finish (no loop, no fade, no snooze).
 * - Auto-dismisses when the audio completes.
 * - STOP ALARM (screen or notification) stops immediately.
 * - If the audio is missing/unplayable: shows a message, plays the system alarm tone + vibration
 *   until the user stops it (max [FALLBACK_MAX_MS]), so a broken file never means a silent alarm.
 * - If a second alarm fires while one is ringing, the new alarm takes over (the old one is dismissed).
 */
class AlarmService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var focusRequest: AudioFocusRequest? = null
    private var currentAlarmId: Long? = null

    private val alarmAudioAttributes: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private val fallbackTimeout = Runnable {
        L.w("Fallback alarm reached max duration; auto-stopping")
        stopAlarm("fallback timeout")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val id = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
                handleStart(id)
            }
            ACTION_STOP -> {
                L.i("STOP ALARM pressed")
                stopAlarm("user pressed STOP")
            }
            else -> {
                L.w("AlarmService started with unknown intent ${intent?.action}")
                if (currentAlarmId == null) stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun handleStart(alarmId: Long) {
        if (currentAlarmId != null && currentAlarmId != alarmId) {
            L.i("Alarm $currentAlarmId is still ringing; new alarm $alarmId takes over")
        }
        releasePlayback()
        currentAlarmId = alarmId

        // Publish state BEFORE the notification so the full-screen activity sees it immediately.
        RingingState.mutable.value = RingingState.Ringing(alarmId, "", "", null)
        startInForeground(alarmId, "Alarm ringing")
        acquireWakeLock()

        scope.launch {
            val alarm = withContext(Dispatchers.IO) {
                val dao = AppDatabase.get(applicationContext).alarmDao()
                dao.getById(alarmId)?.also {
                    if (it.isRepeating()) {
                        // Weekly alarm: queue the next occurrence right away.
                        AlarmScheduler(applicationContext).schedule(it)
                    } else {
                        dao.setEnabled(alarmId, false) // one-time: mark done so it never re-fires
                    }
                }
            }
            if (currentAlarmId != alarmId) return@launch // superseded meanwhile
            if (alarm == null) {
                L.w("Alarm $alarmId no longer exists; ringing with default tone")
                RingingState.mutable.value = RingingState.Ringing(alarmId, "Alarm", "", null)
                fallback("This alarm was not found. Playing the default alarm sound.")
                return@launch
            }
            val label = alarm.label.ifBlank { "Alarm" }
            RingingState.mutable.value = RingingState.Ringing(
                alarmId, label, AlarmFormat.date(java.time.LocalDate.now()), null
            )
            updateNotification(alarmId, "$label • ${AlarmFormat.time(this@AlarmService, alarm)}")
            play(alarm)
        }
    }

    // ---------------------------------------------------------------- playback

    private fun play(alarm: Alarm) {
        val uriString = alarm.audioUri
        if (uriString.isNullOrBlank()) {
            fallback("No audio file selected for this alarm. Playing the default alarm sound.")
            return
        }
        requestAudioFocus()
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(alarmAudioAttributes)
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK) // keeps playing with screen off
            mp.isLooping = false
            mp.setOnPreparedListener {
                if (player === it) {
                    L.i("Playing '${alarm.audioName}' (${it.duration / 1000}s) for alarm ${alarm.id}")
                    it.start()
                }
            }
            mp.setOnCompletionListener {
                if (player === it) {
                    L.i("Audio finished for alarm ${alarm.id}; auto-dismissing")
                    stopAlarm("audio completed")
                }
            }
            mp.setOnErrorListener { p, what, extra ->
                if (player === p) {
                    L.e("MediaPlayer error what=$what extra=$extra for ${alarm.audioUri}")
                    fallback("The selected audio could not be played. Playing the default alarm sound.")
                }
                true
            }
            mp.setDataSource(applicationContext, Uri.parse(uriString))
            mp.prepareAsync()
        } catch (e: Exception) {
            L.e("Cannot open audio ${alarm.audioUri}", e)
            fallback("The selected audio file is missing or cannot be opened. Playing the default alarm sound.")
        }
    }

    private fun fallback(message: String) {
        releasePlayer()
        RingingState.mutable.value = RingingState.mutable.value?.copy(message = message)
            ?: RingingState.Ringing(currentAlarmId ?: -1L, "Alarm", "", message)
        L.w("Fallback: $message")
        requestAudioFocus()

        val toneUri: Uri? = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: Settings.System.DEFAULT_RINGTONE_URI
        if (toneUri != null) {
            val mp = MediaPlayer()
            player = mp
            try {
                mp.setAudioAttributes(alarmAudioAttributes)
                mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                mp.isLooping = true // only the emergency default tone repeats, so the alarm is never silent
                mp.setOnErrorListener { _, what, extra ->
                    L.e("Default tone failed what=$what extra=$extra; vibration only")
                    true
                }
                mp.setDataSource(applicationContext, toneUri)
                mp.setOnPreparedListener { it.start() }
                mp.prepareAsync()
            } catch (e: Exception) {
                L.e("Default alarm tone unavailable; vibration only", e)
                releasePlayer()
            }
        }
        startVibration()
        handler.removeCallbacks(fallbackTimeout)
        handler.postDelayed(fallbackTimeout, FALLBACK_MAX_MS)
    }

    private fun startVibration() {
        val v = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (v == null || !v.hasVibrator()) return
        vibrator = v
        val effect = VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            v.vibrate(effect, VibrationAttributes.createForUsage(VibrationAttributes.USAGE_ALARM))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(effect, alarmAudioAttributes)
        }
    }

    private fun requestAudioFocus() {
        if (focusRequest != null) return
        val am = getSystemService(AudioManager::class.java) ?: return
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(alarmAudioAttributes)
            .setOnAudioFocusChangeListener { change ->
                // Deliberately ignored: an alarm must not pause or duck when another app grabs focus.
                L.d("Audio focus change $change ignored")
            }
            .build()
        am.requestAudioFocus(req)
        focusRequest = req
    }

    // ---------------------------------------------------------------- stop / cleanup

    private fun stopAlarm(reason: String) {
        L.i("Stopping alarm $currentAlarmId ($reason)")
        releasePlayback()
        currentAlarmId = null
        RingingState.mutable.value = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releasePlayer() {
        player?.let {
            try {
                it.setOnCompletionListener(null)
                it.setOnErrorListener(null)
                if (it.isPlaying) it.stop()
            } catch (_: IllegalStateException) {
            }
            it.release()
        }
        player = null
    }

    private fun releasePlayback() {
        handler.removeCallbacks(fallbackTimeout)
        releasePlayer()
        vibrator?.cancel()
        vibrator = null
        focusRequest?.let { getSystemService(AudioManager::class.java)?.abandonAudioFocusRequest(it) }
        focusRequest = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(PowerManager::class.java) ?: return
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NoSnoozeAlarm:ringing").apply {
            setReferenceCounted(false)
            acquire(WAKELOCK_MAX_MS) // safety cap; MediaPlayer holds its own lock while playing
        }
    }

    override fun onDestroy() {
        L.d("AlarmService destroyed")
        releasePlayback()
        if (currentAlarmId != null) RingingState.mutable.value = null
        scope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- notification

    private fun startInForeground(alarmId: Long, text: String) {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        } else 0
        ServiceCompat.startForeground(
            this, Notifications.NOTIFICATION_ID_RINGING, buildNotification(alarmId, text), type
        )
    }

    private fun updateNotification(alarmId: Long, text: String) {
        getSystemService(NotificationManager::class.java)
            ?.notify(Notifications.NOTIFICATION_ID_RINGING, buildNotification(alarmId, text))
    }

    private fun buildNotification(alarmId: Long, text: String): Notification {
        val ringingScreen = PendingIntent.getActivity(
            this, 0,
            Intent(this, AlarmRingingActivity::class.java)
                .putExtra(EXTRA_ALARM_ID, alarmId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AlarmService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Notifications.CHANNEL_ALARM)
            .setSmallIcon(R.drawable.ic_alarm)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setFullScreenIntent(ringingScreen, true)
            .setContentIntent(ringingScreen)
            .addAction(0, "STOP ALARM", stop)
            .build()
    }

    companion object {
        const val ACTION_START = "com.nosnooze.alarm.ACTION_START"
        const val ACTION_STOP = "com.nosnooze.alarm.ACTION_STOP"
        const val EXTRA_ALARM_ID = "alarm_id"

        private const val FALLBACK_MAX_MS = 10 * 60 * 1000L
        private const val WAKELOCK_MAX_MS = 3 * 60 * 60 * 1000L

        fun start(context: Context, alarmId: Long) {
            val i = Intent(context, AlarmService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_ALARM_ID, alarmId)
            ContextCompat.startForegroundService(context, i)
        }

        fun stop(context: Context) {
            // Delivered to the already-running foreground service.
            context.startService(Intent(context, AlarmService::class.java).setAction(ACTION_STOP))
        }
    }
}
