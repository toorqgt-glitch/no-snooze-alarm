package com.nosnooze.alarm.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.nosnooze.alarm.R
import com.nosnooze.alarm.data.Alarm

class AlarmAdapter(
    private val onToggle: (Alarm, Boolean) -> Unit,
    private val onEdit: (Alarm) -> Unit,
    private val onDelete: (Alarm) -> Unit,
) : ListAdapter<Alarm, AlarmAdapter.VH>(DIFF) {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val time: TextView = view.findViewById(R.id.tvTime)
        val date: TextView = view.findViewById(R.id.tvDate)
        val label: TextView = view.findViewById(R.id.tvLabel)
        val audio: TextView = view.findViewById(R.id.tvAudio)
        val status: TextView = view.findViewById(R.id.tvStatus)
        val enabled: MaterialSwitch = view.findViewById(R.id.switchEnabled)
        val edit: MaterialButton = view.findViewById(R.id.btnEdit)
        val delete: MaterialButton = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_alarm, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val alarm = getItem(position)
        val ctx = holder.itemView.context
        holder.time.text = AlarmFormat.time(ctx, alarm)
        holder.date.text = AlarmFormat.schedule(alarm)
        holder.label.text = alarm.label
        holder.label.visibility = if (alarm.label.isBlank()) View.GONE else View.VISIBLE
        holder.audio.text = "♪ " + (alarm.audioName ?: "No audio selected (default alarm tone)")

        val past = alarm.isInPast()
        val (statusText, colorRes) = when {
            alarm.enabled && !past -> (if (alarm.isRepeating()) "ON — repeats weekly" else "ON — will ring once") to R.color.status_on
            past -> "Done / past — edit to set a new time" to R.color.status_off
            else -> "OFF" to R.color.status_off
        }
        holder.status.text = statusText
        holder.status.setTextColor(ContextCompat.getColor(ctx, colorRes))
        holder.itemView.alpha = if (alarm.enabled && !past) 1f else 0.6f

        holder.enabled.setOnCheckedChangeListener(null)
        holder.enabled.isChecked = alarm.enabled && !past
        holder.enabled.setOnCheckedChangeListener { _, checked -> onToggle(alarm, checked) }
        holder.edit.setOnClickListener { onEdit(alarm) }
        holder.delete.setOnClickListener { onDelete(alarm) }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Alarm>() {
            override fun areItemsTheSame(a: Alarm, b: Alarm) = a.id == b.id
            override fun areContentsTheSame(a: Alarm, b: Alarm) = a == b
        }
    }
}
