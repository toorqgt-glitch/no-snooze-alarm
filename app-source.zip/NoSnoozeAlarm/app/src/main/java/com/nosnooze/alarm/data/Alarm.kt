package com.nosnooze.alarm.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * A one-shot alarm at a specific local date and time.
 * Date/time are stored as local wall-clock fields (not epoch millis) so that the alarm
 * keeps ringing at the same clock time after a time zone change.
 */
@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val year: Int,
    val month: Int, // 1-12
    val day: Int,
    val hour: Int,
    val minute: Int,
    val label: String = "",
    val audioUri: String? = null,
    val audioName: String? = null,
    val enabled: Boolean = true,
) {
    fun localDateTime(): LocalDateTime = LocalDateTime.of(year, month, day, hour, minute)

    fun triggerAtMillis(zone: ZoneId = ZoneId.systemDefault()): Long =
        localDateTime().atZone(zone).toInstant().toEpochMilli()

    fun isInPast(now: Long = System.currentTimeMillis()): Boolean = triggerAtMillis() <= now

    /** PendingIntent request codes are Ints; ids stay far below Int.MAX_VALUE for personal use. */
    fun requestCode(): Int = (id % Int.MAX_VALUE).toInt()
}
