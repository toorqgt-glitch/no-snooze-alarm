package com.nosnooze.alarm.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/**
 * An alarm at a local wall-clock time.
 *
 * - repeatDays == 0  → one-time alarm on year/month/day.
 * - repeatDays != 0  → weekly alarm on the selected days (bit 0 = Monday … bit 6 = Sunday);
 *                      year/month/day are ignored.
 *
 * Stored as local fields (not epoch millis) so the alarm keeps the same clock time
 * after a time zone change.
 */
@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val year: Int,
    val month: Int, // 1-12
    val day: Int,
    val hour: Int,
    val minute: Int,
    val label: String = "",
    val audioUri: String? = null,
    val audioName: String? = null,
    val enabled: Boolean = true,
    val repeatDays: Int = 0,
) {
    fun isRepeating(): Boolean = repeatDays != 0

    fun repeatsOn(day: DayOfWeek): Boolean = repeatDays and dayBit(day) != 0

    fun localDateTime(): LocalDateTime = LocalDateTime.of(year, month, day, hour, minute)

    /** Next time this alarm should ring strictly after [now], or null if a one-time alarm has passed. */
    fun nextTriggerMillis(now: Long = System.currentTimeMillis(), zone: ZoneId = ZoneId.systemDefault()): Long? {
        if (!isRepeating()) {
            val t = localDateTime().atZone(zone).toInstant().toEpochMilli()
            return if (t > now) t else null
        }
        val today = java.time.Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val time = LocalTime.of(hour, minute)
        for (offset in 0..7) {
            val date = today.plusDays(offset.toLong())
            if (!repeatsOn(date.dayOfWeek)) continue
            val t = LocalDateTime.of(date, time).atZone(zone).toInstant().toEpochMilli()
            if (t > now) return t
        }
        return null // unreachable when repeatDays != 0
    }

    fun nextTriggerDate(now: Long = System.currentTimeMillis(), zone: ZoneId = ZoneId.systemDefault()): LocalDate? =
        nextTriggerMillis(now, zone)?.let { java.time.Instant.ofEpochMilli(it).atZone(zone).toLocalDate() }

    fun isInPast(now: Long = System.currentTimeMillis()): Boolean = nextTriggerMillis(now) == null

    /** PendingIntent request codes are Ints; ids stay far below Int.MAX_VALUE for personal use. */
    fun requestCode(): Int = (id % Int.MAX_VALUE).toInt()

    companion object {
        const val EVERY_DAY = 0b1111111
        const val WEEKDAYS = 0b0011111
        const val WEEKENDS = 0b1100000

        fun dayBit(day: DayOfWeek): Int = 1 shl (day.value - 1)
    }
}
