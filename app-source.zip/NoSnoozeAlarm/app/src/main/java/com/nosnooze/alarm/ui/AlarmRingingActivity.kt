package com.nosnooze.alarm.ui

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import com.nosnooze.alarm.L
import com.nosnooze.alarm.R
import com.nosnooze.alarm.alarm.AlarmService
import com.nosnooze.alarm.alarm.RingingState
import kotlinx.coroutines.launch

/** Full-screen ringing UI. One action only: STOP ALARM. No snooze. */
class AlarmRingingActivity : AppCompatActivity() {

    private var seenRinging = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showOverLockScreen()
        setContentView(R.layout.activity_alarm_ringing)

        val tvDate = findViewById<TextView>(R.id.tvDate)
        val tvLabel = findViewById<TextView>(R.id.tvLabel)
        val tvMessage = findViewById<TextView>(R.id.tvMessage)

        findViewById<MaterialButton>(R.id.btnStop).setOnClickListener {
            L.i("STOP ALARM tapped on ringing screen")
            AlarmService.stop(this)
            finish()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                Toast.makeText(this@AlarmRingingActivity, "Press STOP ALARM", Toast.LENGTH_SHORT).show()
            }
        })

        // Fallback path: alarm fired inexactly and the service could not start from the background.
        if (RingingState.current.value == null && intent.getBooleanExtra(EXTRA_START_SERVICE, false)) {
            val id = intent.getLongExtra(AlarmService.EXTRA_ALARM_ID, -1L)
            if (id >= 0) {
                L.i("Starting alarm service from ringing screen for alarm $id")
                AlarmService.start(this, id)
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                RingingState.current.collect { state ->
                    if (state == null) {
                        val starting = intent.getBooleanExtra(EXTRA_START_SERVICE, false) && !seenRinging
                        if (!starting) finish() // alarm stopped or finished on its own
                        return@collect
                    }
                    seenRinging = true
                    tvLabel.text = state.label.ifBlank { "Alarm" }
                    tvDate.text = state.dateText
                    tvDate.visibility = if (state.dateText.isBlank()) View.GONE else View.VISIBLE
                    tvMessage.text = state.message
                    tvMessage.visibility = if (state.message == null) View.GONE else View.VISIBLE
                }
            }
        }
    }

    private fun showOverLockScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    companion object {
        const val EXTRA_START_SERVICE = "start_service"
    }
}
