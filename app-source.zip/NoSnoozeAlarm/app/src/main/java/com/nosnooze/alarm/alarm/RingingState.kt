package com.nosnooze.alarm.alarm

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** In-process state shared between AlarmService (writer) and AlarmRingingActivity (reader). */
object RingingState {
    data class Ringing(
        val alarmId: Long,
        val label: String,
        val dateText: String,
        val message: String?, // non-null when the selected audio could not be played
    )

    internal val mutable = MutableStateFlow<Ringing?>(null)
    val current: StateFlow<Ringing?> = mutable
}
