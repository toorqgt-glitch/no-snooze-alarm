package com.nosnooze.alarm.ui

import android.content.Context
import android.text.format.DateFormat
import com.nosnooze.alarm.data.Alarm
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object AlarmFormat {
    fun time(context: Context, hour: Int, minute: Int): String {
        val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm a"
        return LocalTime.of(hour, minute).format(DateTimeFormatter.ofPattern(pattern, Locale.getDefault()))
    }

    fun time(context: Context, alarm: Alarm): String = time(context, alarm.hour, alarm.minute)

    fun date(date: LocalDate): String =
        date.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.getDefault()))

    fun date(alarm: Alarm): String = date(LocalDate.of(alarm.year, alarm.month, alarm.day))

    /** "Every day", "Weekdays", "Weekends" or "Mon, Wed, Fri". Empty for one-time alarms. */
    fun repeat(repeatDays: Int): String = when (repeatDays) {
        0 -> ""
        Alarm.EVERY_DAY -> "Every day"
        Alarm.WEEKDAYS -> "Weekdays (Mon–Fri)"
        Alarm.WEEKENDS -> "Weekends (Sat–Sun)"
        else -> java.time.DayOfWeek.values()
            .filter { repeatDays and Alarm.dayBit(it) != 0 }
            .joinToString(", ") { it.getDisplayName(java.time.format.TextStyle.SHORT, Locale.getDefault()) }
    }

    /** Line under the time: repeat days + next ring date, or the one-time date. */
    fun schedule(alarm: Alarm): String {
        if (!alarm.isRepeating()) return date(alarm)
        val next = alarm.nextTriggerDate()
        val nextText = next?.let {
            " • next " + it.format(DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()))
        }.orEmpty()
        return "🔁 " + repeat(alarm.repeatDays) + nextText
    }
}
