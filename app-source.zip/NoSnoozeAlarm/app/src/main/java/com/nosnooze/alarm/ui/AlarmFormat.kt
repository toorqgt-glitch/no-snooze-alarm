package com.nosnooze.alarm.ui

import android.content.Context
import android.text.format.DateFormat
import com.nosnooze.alarm.data.Alarm
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object AlarmFormat {
    fun time(context: Context, hour: Int, minute: Int): String {
        val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm a"
        return LocalTime.of(hour, minute).format(DateTimeFormatter.ofPattern(pattern, Locale.getDefault()))
    }

    fun time(context: Context, alarm: Alarm): String = time(context, alarm.hour, alarm.minute)

    fun date(date: LocalDate): String =
        date.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.getDefault()))

    fun date(alarm: Alarm): String = date(LocalDate.of(alarm.year, alarm.month, alarm.day))
}
