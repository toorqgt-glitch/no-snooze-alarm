package com.nosnooze.alarm.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.format.DateFormat
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.textfield.TextInputEditText
import com.nosnooze.alarm.L
import com.nosnooze.alarm.alarm.ScheduleResult
import com.nosnooze.alarm.data.Alarm
import com.nosnooze.alarm.data.AlarmRepository
import com.nosnooze.alarm.R
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

class AddEditAlarmActivity : AppCompatActivity() {

    private lateinit var repo: AlarmRepository
    private lateinit var btnTime: MaterialButton
    private lateinit var btnDate: MaterialButton
    private lateinit var btnPreview: MaterialButton
    private lateinit var tvAudio: TextView
    private lateinit var etLabel: TextInputEditText

    private var existing: Alarm? = null
    private var date: LocalDate = LocalDate.now()
    private var hour = 7
    private var minute = 0
    private var audioUri: String? = null
    private var audioName: String? = null
    private var repeatDays: Int = 0
    private lateinit var dayChips: List<Pair<DayOfWeek, Chip>>
    private lateinit var tvDateHint: TextView

    private var previewPlayer: MediaPlayer? = null

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        stopPreview()
        if (!AlarmRepository.takeReadPermission(this, uri)) {
            Toast.makeText(
                this, "Warning: Android did not grant lasting access to this file. Pick it from internal storage via the Files picker.",
                Toast.LENGTH_LONG
            ).show()
        }
        audioUri = uri.toString()
        audioName = displayName(uri)
        L.i("Selected audio $audioName ($audioUri)")
        renderAudio()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener { finish() }
        repo = AlarmRepository(this)

        btnTime = findViewById(R.id.btnTime)
        btnDate = findViewById(R.id.btnDate)
        btnPreview = findViewById(R.id.btnPreview)
        tvAudio = findViewById(R.id.tvAudioName)
        etLabel = findViewById(R.id.etLabel)
        tvDateHint = findViewById(R.id.tvDateHint)
        dayChips = listOf(
            DayOfWeek.MONDAY to R.id.chipMon, DayOfWeek.TUESDAY to R.id.chipTue,
            DayOfWeek.WEDNESDAY to R.id.chipWed, DayOfWeek.THURSDAY to R.id.chipThu,
            DayOfWeek.FRIDAY to R.id.chipFri, DayOfWeek.SATURDAY to R.id.chipSat,
            DayOfWeek.SUNDAY to R.id.chipSun,
        ).map { (d, id) -> d to findViewById<Chip>(id) }
        dayChips.forEach { (day, chip) ->
            chip.setOnClickListener {
                repeatDays = if (chip.isChecked) repeatDays or Alarm.dayBit(day)
                else repeatDays and Alarm.dayBit(day).inv()
                renderAll()
            }
        }
        findViewById<MaterialButton>(R.id.btnEveryDay).setOnClickListener { repeatDays = Alarm.EVERY_DAY; renderAll() }
        findViewById<MaterialButton>(R.id.btnWeekdays).setOnClickListener { repeatDays = Alarm.WEEKDAYS; renderAll() }
        findViewById<MaterialButton>(R.id.btnOnce).setOnClickListener { repeatDays = 0; renderAll() }

        // Default for a new alarm: next whole hour.
        val next = LocalDateTime.now().plusHours(1)
        date = next.toLocalDate(); hour = next.hour; minute = 0

        savedInstanceState?.let { s ->
            date = LocalDate.ofEpochDay(s.getLong(K_DATE))
            hour = s.getInt(K_HOUR); minute = s.getInt(K_MIN)
            audioUri = s.getString(K_URI); audioName = s.getString(K_NAME)
            repeatDays = s.getInt(K_REPEAT)
        }

        val id = intent.getLongExtra(EXTRA_ALARM_ID, 0L)
        if (id != 0L) {
            title = "Edit alarm"
            lifecycleScope.launch {
                val a = repo.get(id)
                if (a == null) {
                    Toast.makeText(this@AddEditAlarmActivity, "Alarm not found", Toast.LENGTH_SHORT).show()
                    finish(); return@launch
                }
                existing = a
                if (savedInstanceState == null) {
                    date = LocalDate.of(a.year, a.month, a.day); hour = a.hour; minute = a.minute
                    audioUri = a.audioUri; audioName = a.audioName
                    repeatDays = a.repeatDays
                    etLabel.setText(a.label)
                }
                renderAll()
            }
        } else {
            title = "Add alarm"
        }
        renderAll()

        btnTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m -> hour = h; minute = m; renderAll() },
                hour, minute, DateFormat.is24HourFormat(this)).show()
        }
        btnDate.setOnClickListener {
            DatePickerDialog(this, { _, y, mo, d -> date = LocalDate.of(y, mo + 1, d); renderAll() },
                date.year, date.monthValue - 1, date.dayOfMonth).apply {
                datePicker.minDate = System.currentTimeMillis() - 1000
            }.show()
        }
        findViewById<MaterialButton>(R.id.btnPickAudio).setOnClickListener {
            pickAudio.launch(arrayOf("audio/*", "application/ogg"))
        }
        btnPreview.setOnClickListener { if (previewPlayer != null) stopPreview() else startPreview() }
        findViewById<MaterialButton>(R.id.btnCancel).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener { save() }
    }

    private fun renderAll() {
        btnTime.text = AlarmFormat.time(this, hour, minute)
        btnDate.text = AlarmFormat.date(date)
        dayChips.forEach { (day, chip) -> chip.isChecked = repeatDays and Alarm.dayBit(day) != 0 }
        val repeating = repeatDays != 0
        btnDate.isEnabled = !repeating
        btnDate.alpha = if (repeating) 0.4f else 1f
        tvDateHint.text = if (repeating) "Repeats: ${AlarmFormat.repeat(repeatDays)} — date not needed"
        else "One-time alarm on the date below. Tap days above to repeat weekly."
        renderAudio()
    }

    private fun renderAudio() {
        tvAudio.text = audioName ?: "No audio selected — the default alarm tone will be used"
        btnPreview.isEnabled = audioUri != null
        btnPreview.text = if (previewPlayer != null) "Stop preview" else "Preview"
    }

    private fun save() {
        val whenLocal = LocalDateTime.of(date.year, date.monthValue, date.dayOfMonth, hour, minute)
        if (repeatDays == 0 &&
            whenLocal.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() <= System.currentTimeMillis()
        ) {
            Toast.makeText(this, "Please choose a time in the future.", Toast.LENGTH_LONG).show()
            return
        }
        val alarm = Alarm(
            id = existing?.id ?: 0L,
            year = date.year, month = date.monthValue, day = date.dayOfMonth,
            hour = hour, minute = minute,
            label = etLabel.text?.toString()?.trim().orEmpty(),
            audioUri = audioUri, audioName = audioName,
            enabled = true,
            repeatDays = repeatDays,
        )
        lifecycleScope.launch {
            val result = repo.save(alarm)
            val msg = when (result) {
                ScheduleResult.EXACT -> "Alarm set: ${AlarmFormat.time(this@AddEditAlarmActivity, alarm)}, ${AlarmFormat.schedule(alarm)}"
                ScheduleResult.INEXACT -> "Saved, but exact alarms are NOT allowed — it may ring late. Open Help to fix."
                ScheduleResult.IN_PAST -> "That time has already passed."
                ScheduleResult.DISABLED -> "Saved (off)."
            }
            Toast.makeText(this@AddEditAlarmActivity, msg, Toast.LENGTH_LONG).show()
            if (result != ScheduleResult.IN_PAST) finish()
        }
    }

    private fun startPreview() {
        val uri = audioUri ?: return
        val mp = MediaPlayer()
        previewPlayer = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(this, Uri.parse(uri))
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { stopPreview() }
            mp.setOnErrorListener { _, what, extra ->
                L.e("Preview error what=$what extra=$extra")
                Toast.makeText(this, "This file can't be played on this phone.", Toast.LENGTH_LONG).show()
                stopPreview(); true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            L.e("Preview failed for $uri", e)
            Toast.makeText(this, "Audio file is missing or unreadable. Choose it again.", Toast.LENGTH_LONG).show()
            stopPreview()
        }
        renderAudio()
    }

    private fun stopPreview() {
        previewPlayer?.let {
            try { if (it.isPlaying) it.stop() } catch (_: IllegalStateException) {}
            it.release()
        }
        previewPlayer = null
        if (::btnPreview.isInitialized) renderAudio()
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) c.getString(idx)?.let { return it }
                }
            }
        } catch (e: Exception) {
            L.w("Could not read display name for $uri", e)
        }
        return uri.lastPathSegment ?: "Selected audio"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(K_DATE, date.toEpochDay())
        outState.putInt(K_HOUR, hour); outState.putInt(K_MIN, minute)
        outState.putString(K_URI, audioUri); outState.putString(K_NAME, audioName)
        outState.putInt(K_REPEAT, repeatDays)
    }

    override fun onStop() {
        super.onStop()
        stopPreview()
    }

    companion object {
        const val EXTRA_ALARM_ID = "alarm_id"
        private const val K_DATE = "date"
        private const val K_HOUR = "hour"
        private const val K_MIN = "minute"
        private const val K_URI = "uri"
        private const val K_NAME = "name"
        private const val K_REPEAT = "repeat"
    }
}
