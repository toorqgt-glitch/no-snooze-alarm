package com.nosnooze.alarm.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

object Notifications {
    const val CHANNEL_ALARM = "alarm_ringing_v1"
    const val NOTIFICATION_ID_RINGING = 1001

    fun createChannels(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ALARM, "Ringing alarms", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Shows the alarm screen and STOP ALARM button while an alarm rings"
            setSound(null, null) // audio is played by AlarmService with USAGE_ALARM
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setBypassDnd(true)
        }
        nm.createNotificationChannel(channel)
    }

    fun isAlarmChannelEnabled(context: Context): Boolean {
        val nm = context.getSystemService(NotificationManager::class.java)
        val ch = nm.getNotificationChannel(CHANNEL_ALARM) ?: return true
        return ch.importance != NotificationManager.IMPORTANCE_NONE
    }
}
