package com.nosnooze.alarm.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.nosnooze.alarm.L
import com.nosnooze.alarm.data.Alarm
import com.nosnooze.alarm.ui.MainActivity

class AlarmScheduler(private val context: Context) {

    private val alarmManager: AlarmManager = context.getSystemService(AlarmManager::class.java)

    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    fun schedule(alarm: Alarm): ScheduleResult {
        // Always cancel first: guarantees exactly one pending trigger per alarm id.
        cancel(alarm.id)
        if (!alarm.enabled) return ScheduleResult.DISABLED

        val trigger = alarm.triggerAtMillis()
        if (trigger <= System.currentTimeMillis()) {
            L.w("Alarm ${alarm.id} not scheduled: ${alarm.localDateTime()} is in the past")
            return ScheduleResult.IN_PAST
        }

        val fire = firePendingIntent(alarm.id, alarm.requestCode())
        return try {
            if (canScheduleExact()) {
                val showIntent = PendingIntent.getActivity(
                    context, alarm.requestCode(),
                    Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                alarmManager.setAlarmClock(AlarmManager.AlarmClockInfo(trigger, showIntent), fire)
                L.i("Alarm ${alarm.id} scheduled EXACT for ${alarm.localDateTime()}")
                ScheduleResult.EXACT
            } else {
                scheduleInexact(alarm, trigger, fire)
            }
        } catch (e: SecurityException) {
            L.e("Exact alarm permission denied at schedule time; falling back", e)
            scheduleInexact(alarm, trigger, fire)
        }
    }

    private fun scheduleInexact(alarm: Alarm, trigger: Long, fire: PendingIntent): ScheduleResult {
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, fire)
        L.w("Alarm ${alarm.id} scheduled INEXACT (no exact-alarm permission) for ${alarm.localDateTime()}")
        return ScheduleResult.INEXACT
    }

    fun cancel(alarmId: Long) {
        val requestCode = (alarmId % Int.MAX_VALUE).toInt()
        val pi = PendingIntent.getBroadcast(
            context, requestCode, baseIntent(alarmId),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            alarmManager.cancel(pi)
            pi.cancel()
            L.d("Cancelled pending trigger for alarm $alarmId")
        }
    }

    private fun baseIntent(alarmId: Long): Intent =
        Intent(context, AlarmReceiver::class.java)
            .setAction(AlarmReceiver.ACTION_FIRE)
            .setData(Uri.parse("nosnooze://alarm/$alarmId")) // unique per alarm
            .putExtra(AlarmService.EXTRA_ALARM_ID, alarmId)

    private fun firePendingIntent(alarmId: Long, requestCode: Int): PendingIntent =
        PendingIntent.getBroadcast(
            context, requestCode, baseIntent(alarmId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}
