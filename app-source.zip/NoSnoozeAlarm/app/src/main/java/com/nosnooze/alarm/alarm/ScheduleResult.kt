package com.nosnooze.alarm.alarm

enum class ScheduleResult {
    /** Registered with AlarmManager.setAlarmClock (exact, survives Doze, shows in status bar). */
    EXACT,
    /** Exact alarms not permitted: registered inexactly; may be delayed by the system. */
    INEXACT,
    /** Time already passed; nothing scheduled. */
    IN_PAST,
    /** Alarm disabled; any existing schedule was cancelled. */
    DISABLED,
}
