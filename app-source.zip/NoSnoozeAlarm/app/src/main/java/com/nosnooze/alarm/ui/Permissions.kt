package com.nosnooze.alarm.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.nosnooze.alarm.L
import com.nosnooze.alarm.alarm.AlarmScheduler
import com.nosnooze.alarm.alarm.Notifications

/** Permission/status checks and deep links into the right system settings pages. */
object Permissions {

    fun exactAlarmsAllowed(context: Context) = AlarmScheduler(context).canScheduleExact()

    fun notificationsAllowed(context: Context): Boolean {
        val runtimeOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        return runtimeOk && NotificationManagerCompat.from(context).areNotificationsEnabled() &&
            Notifications.isAlarmChannelEnabled(context)
    }

    fun fullScreenAllowed(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 34) {
            context.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
        } else true

    fun ignoringBatteryOptimizations(context: Context): Boolean =
        context.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName)

    /** Returns current/max alarm stream volume. */
    fun alarmVolume(context: Context): Pair<Int, Int> {
        val am = context.getSystemService(AudioManager::class.java)
        return am.getStreamVolume(AudioManager.STREAM_ALARM) to am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
    }

    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            launch(context, Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri(context)))
        } else openAppDetails(context)
    }

    fun openNotificationSettings(context: Context) {
        launch(
            context,
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        )
    }

    fun openFullScreenSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= 34) {
            launch(context, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkgUri(context)))
        } else openNotificationSettings(context)
    }

    @SuppressLint("BatteryLife")
    fun requestIgnoreBatteryOptimizations(context: Context) {
        val direct = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri(context))
        if (!launch(context, direct)) {
            launch(context, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    fun openAppDetails(context: Context) {
        launch(context, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri(context)))
    }

    private fun pkgUri(context: Context) = Uri.parse("package:${context.packageName}")

    private fun launch(context: Context, intent: Intent): Boolean = try {
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        L.w("No settings screen for ${intent.action}", e)
        if (intent.action != Settings.ACTION_APPLICATION_DETAILS_SETTINGS) openAppDetails(context)
        false
    }
}
